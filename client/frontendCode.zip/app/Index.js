import { NavigationContainer } from '@react-navigation/native';
import Layout from './_layout';

const Index = () => {
  return(
    <NavigationContainer>
      <Layout/>
    </NavigationContainer>
  )
  
}

export default Index