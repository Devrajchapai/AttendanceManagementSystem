import { Text, View } from 'react-native'

const TeacherHomePage = () => {
  return (
    <View>
      <Text>TeacherHomePage</Text>
    </View>
  )
}

export default TeacherHomePage