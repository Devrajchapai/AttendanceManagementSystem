import { Text, View } from 'react-native'

const AdminHomePage = () => {
  return (
    <View>
      <Text>AdminHomePage</Text>
    </View>
  )
}

export default AdminHomePage